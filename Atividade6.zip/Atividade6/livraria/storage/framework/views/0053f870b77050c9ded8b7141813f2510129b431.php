
<form action="<?php echo e(route('autores.update', ['id'=>$autor->id_autor])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	<b>Nome: </b><input type="text" name="Nome" value="<?php echo e($autor->Nome); ?>"><br><br>
	<b>Nacionalidade: </b><input type="text" name="Nacionalidade" value="<?php echo e($autor->Nacionalidade); ?>"><br><br>
	<b>Data_Nascimento: </b><input type="text" name="" value="<?php echo e($autor->Data_Nascimento); ?>"><br><br>
	<b>Fotografia: </b><input type="date" name="data_edicao" value="<?php echo e($autor->Fotografia); ?>"><br><br>
	<input type="submit" value="Enviar">
</form>


<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/autores/edit.blade.php ENDPATH**/ ?>