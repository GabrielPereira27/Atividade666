ID:<?php echo e($editoras->ide); ?><br>
Título:<?php echo e($editoras->nome); ?><br>
Idioma:<?php echo e($editoras->idioma); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/editoras/show.blade.php ENDPATH**/ ?>