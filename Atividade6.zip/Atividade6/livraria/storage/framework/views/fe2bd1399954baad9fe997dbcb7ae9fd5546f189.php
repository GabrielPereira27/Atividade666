ID:<?php echo e($editoras->id_editora); ?><br>
Nome:<?php echo e($editoras->nome); ?><br>
Morada:<?php echo e($editoras->morada); ?><br>
Observacoes:<?php echo e($editoras->Observacoes); ?>


<br>
	<br><a href="<?php echo e(route('editoras.edit' , ['id' => $editoras ->id_editora])); ?>"><b>Editar</b></a>
	<br><a href="<?php echo e(route('editoras.create' , ['id' => $editoras ->id_editora])); ?>"><b>Criar</b></a>
	<br><a href="<?php echo e(route('editoras.delete' , ['id' => $editoras ->id_editora])); ?>"><b>Eliminar</b></a><?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/editoras/show.blade.php ENDPATH**/ ?>