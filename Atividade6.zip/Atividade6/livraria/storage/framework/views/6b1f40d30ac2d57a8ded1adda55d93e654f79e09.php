<b>Designacao:<?php echo e($genero->Designacao); ?></b><br>
<b>Observacoes:<?php echo e($genero->Observacoes); ?></b><br>
<?php $__currentLoopData = $genero->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($livro->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
	<br><a href="<?php echo e(route('generos.edit' , ['id' => $genero ->id_genero])); ?>"><b>Editar</b></a>
	<br><a href="<?php echo e(route('generos.create' , ['id' => $genero ->id_genero])); ?>"><b>Criar</b></a>
	<br><a href="<?php echo e(route('generos.delete' , ['id' => $genero ->id_genero])); ?>"><b>Eliminar</b></a><?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>