<form action="<?php echo e(route('generos.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<b>Designacao: </b><input type="text" name="Designacao"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes"><br><br>
	<input type="submit" value="Enviar">
</form>

<?php if( $errors-> has('Designacao') ): ?>
<b>Deverá indicar uma Designacao correta<b><br>
<?php endif; ?>

<?php if( $errors-> has('Observacoes') ): ?>
<b>Deverá indicar uma observacao correta. <b><br>
<?php endif; ?>

<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/generos/create.blade.php ENDPATH**/ ?>