<form action="<?php echo e(route('livros.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<b>Título: </b><input type="text" name="titulo"><br><br>
	<b>Idioma: </b><input type="text" name="idioma"><br><br>
	<b>Total Páginas: </b><input type="text" name="total_paginas"><br><br>
	<b>Data Edição: </b><input type="date" name="data_edicao"><br><br>
	<b>ISBN: </b><input type="text" name="isbn" value="<?php echo e(old('isbn')); ?>"><br><br>
	<b>Observações: </b><textarea type="text" name="observacoes"></textarea><br><br>
	<b>Imagem Capa: </b><input type="text" name="imagem_capa"><br><br>
	<b>Gênero: </b><input type="text" name="id_genero"><br><br>
	<b>Autor: </b><input type="text" name="id_autor"><br><br>
	<b>Sinopse: </b><textarea type="text" name="sinopse"></textarea><br>
	<input type="submit" value="Enviar">
</form>

<?php if( $errors-> has('isbn') ): ?>
<b>Deverá indicar um ISBN correto (13 carateres)<b><br>
<?php endif; ?>

<?php if( $errors-> has('titulo') ): ?>
<b>Deverá indicar um Titulo correto. <b><br>
<?php endif; ?>

<?php if( $errors-> has('idioma') ): ?>
<b>Deverá indicar um idioma correto. <b><br>
<?php endif; ?>

<?php if( $errors-> has('total_paginas') ): ?>
<b>Deverá indicar um total de páginas corretas. <b><br>
<?php endif; ?>

<?php if( $errors-> has('data_edicao') ): ?>
<b>Deverá indicar uma data de edicao correta <b><br>
<?php endif; ?>

<?php if( $errors-> has('observacoes') ): ?>
<b>Deverá indicar uma observação correta <b><br>
<?php endif; ?>

<?php if( $errors-> has('imagem_capa') ): ?>
<b>Deverá indicar uma imagem correta <b><br>
<?php endif; ?>

<?php if( $errors-> has('id_genero') ): ?>
<b>Deverá indicar um id correto <b><br>
<?php endif; ?>

<?php if( $errors-> has('id_autor') ): ?>
<b>Deverá indicar um id correto <b><br>
<?php endif; ?>

<?php if( $errors-> has('sinopse') ): ?>
<b>Deverá indicar uma sinopse correto <b><br>
<?php endif; ?>
<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>