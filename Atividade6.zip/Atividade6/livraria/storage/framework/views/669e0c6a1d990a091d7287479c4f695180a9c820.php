<b>ID:<?php echo e($livro->idl); ?></b><br>
<b>Título:<?php echo e($livro->titulo); ?></b><br>
<b>Idioma:<?php echo e($livro->idioma); ?></b><br>
<?php if(isset($livro->genero->designacao)): ?>
<b><?php echo e($livro->genero->designacao); ?></b>
<?php endif; ?><?php /**PATH D:\Gabriel\PSI\Atividade6\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>