ID:<?php echo e($autores->id_autor); ?><br>
Nome:<?php echo e($autores->nome); ?><br>
Nacionalidade:<?php echo e($autores->nacionalidade); ?><br>

<?php $__currentLoopData = $autores->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($livro->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
	<br><a href="<?php echo e(route('autores.edit' , ['id' => $autores ->id_autor])); ?>"><b>Editar</b></a>
	<br><a href="<?php echo e(route('autores.create' , ['id' => $autores ->id_autor])); ?>"><b>Criar</b></a>
	<br><a href="<?php echo e(route('autores.delete' , ['id' => $autores ->id_autor])); ?>"><b>Eliminar</b></a><?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>