
<form action="<?php echo e(route('generos.update', ['id'=>$genero->id_genero])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	<b>Designacao: </b><input type="text" name="Designacao" value="<?php echo e($genero->Designacao); ?>"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes" value="<?php echo e($genero->Observacoes); ?>"><br><br>
	<input type="submit" value="Enviar">
</form>



<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/generos/edit.blade.php ENDPATH**/ ?>