ID:<?php echo e($livro->idl); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>
<?php if(isset($livro->genero->designacao)): ?>
<?php echo e($livro->genero->designacao); ?>

<?php endif; ?><?php /**PATH D:\Gabriel\PSI_\Atividade3\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>