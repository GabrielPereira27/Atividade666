<b>ID:<?php echo e($livro->id_livro); ?></b><br>
<b>Título:<?php echo e($livro->titulo); ?></b><br>
<b>Idioma:<?php echo e($livro->idioma); ?></b><br>

<?php if(isset($livro->genero->designacao)): ?>
<b><?php echo e($livro->genero->designacao); ?></b>
<?php endif; ?>

<?php if(count($livro->autores)>0): ?>

<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($autor->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<div class="alert alert-damage" role="alert">Sem autor definido</div>
<?php endif; ?>
<br>
	<br><a href="<?php echo e(route('livros.edit' , ['id' => $livro ->id_livro])); ?>"><b>Editar</b></a>
	<br><a href="<?php echo e(route('livros.create' , ['id' => $livro ->id_livro])); ?>"><b>Criar</b></a>
	<br><a href="<?php echo e(route('livros.delete' , ['id' => $livro ->id_livro])); ?>"><b>Eliminar</b></a><?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>