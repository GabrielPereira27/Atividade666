
<form action="{{route('editoras.update', ['id'=>$editora->id_editora])}}" method="post">
	@csrf
	@method('patch')

	<b>Nome: </b><input type="text" name="Nome" value="{{$editora->Nome}}"><br><br>
	<b>Morada: </b><input type="text" name="Morada" value="{{$editora->Morada}}"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes" value="{{$editora->Observacoes}}"><br><br>
	<input type="submit" value="Enviar">
</form>



