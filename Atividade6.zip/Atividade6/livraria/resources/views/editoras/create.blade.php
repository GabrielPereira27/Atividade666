<form action="{{route('editoras.store')}}" method="post">
	@csrf
	<b>Nome: </b><input type="text" name="Nome"><br><br>
	<b>Morada: </b><input type="text" name="Morada"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes"><br><br>
	<input type="submit" value="Enviar">
</form>

@if ( $errors-> has('Nome') )
<b>Deverá indicar um nome correto.<b><br>
@endif

@if ( $errors-> has('Morada') )
<b>Deverá indicar uma morada correta.<b><br>
@endif

@if ( $errors-> has('Observacoes') )
<b>Deverá indicar uma observacao correta. <b><br>
@endif
