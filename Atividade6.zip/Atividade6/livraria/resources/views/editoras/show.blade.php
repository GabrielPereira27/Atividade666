ID:{{$editoras->id_editora}}<br>
Nome:{{$editoras->nome}}<br>
Morada:{{$editoras->morada}}<br>
Observacoes:{{$editoras->Observacoes}}

<br>
	<br><a href="{{route('editoras.edit' , ['id' => $editoras ->id_editora])}}"><b>Editar</b></a>
	<br><a href="{{route('editoras.create' , ['id' => $editoras ->id_editora])}}"><b>Criar</b></a>
	<br><a href="{{route('editoras.delete' , ['id' => $editoras ->id_editora])}}"><b>Eliminar</b></a>