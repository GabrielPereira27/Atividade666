ID:{{$autores->id_autor}}<br>
Nome:{{$autores->nome}}<br>
Nacionalidade:{{$autores->nacionalidade}}<br>

@foreach ($autores->livros as $livro)
<h3>{{$livro->titulo}}</h3>
@endforeach

<br>
	<br><a href="{{route('autores.edit' , ['id' => $autores ->id_autor])}}"><b>Editar</b></a>
	<br><a href="{{route('autores.create' , ['id' => $autores ->id_autor])}}"><b>Criar</b></a>
	<br><a href="{{route('autores.delete' , ['id' => $autores ->id_autor])}}"><b>Eliminar</b></a>