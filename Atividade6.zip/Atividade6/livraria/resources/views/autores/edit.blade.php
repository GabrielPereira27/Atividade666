
<form action="{{route('autores.update', ['id'=>$autor->id_autor])}}" method="post">
	@csrf
	@method('patch')

	<b>Nome: </b><input type="text" name="Nome" value="{{$autor->Nome}}"><br><br>
	<b>Nacionalidade: </b><input type="text" name="Nacionalidade" value="{{$autor->Nacionalidade}}"><br><br>
	<b>Data_Nascimento: </b><input type="text" name="" value="{{$autor->Data_Nascimento}}"><br><br>
	<b>Fotografia: </b><input type="date" name="data_edicao" value="{{$autor->Fotografia}}"><br><br>
	<input type="submit" value="Enviar">
</form>


