<b>Designacao:{{$genero->Designacao}}</b><br>
<b>Observacoes:{{$genero->Observacoes}}</b><br>
@foreach ($genero->livros as $livro)
<h3>{{$livro->titulo}}</h3>
@endforeach

<br>
	<br><a href="{{route('generos.edit' , ['id' => $genero ->id_genero])}}"><b>Editar</b></a>
	<br><a href="{{route('generos.create' , ['id' => $genero ->id_genero])}}"><b>Criar</b></a>
	<br><a href="{{route('generos.delete' , ['id' => $genero ->id_genero])}}"><b>Eliminar</b></a>